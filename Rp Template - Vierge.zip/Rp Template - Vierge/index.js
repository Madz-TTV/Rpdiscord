var rpc = require("discord-rpc")
var rpc = require("discord-rpc")
const client = new rpc.Client({ transport: 'ipc' })
client.on('ready', () => {
client.request('SET_ACTIVITY', {
pid: process.pid,

activity : {
details : "Texte 1",
state : "Text 2",

assets : {

large_image : "text",
small_text : "nom de l'image",
small_text : "text",

},
buttons : [
{label : "Bouton 1" , url : "lien"},
{label : "Bouton 2" , url : "lien"},

]
}
})
})

client.login({ clientId : "ID_DU_BOT" }).catch(console.error);
